import { createDecorator } from '../../instantiation/common/instantiation.js';
export const IDialogService = createDecorator('dialogService');
