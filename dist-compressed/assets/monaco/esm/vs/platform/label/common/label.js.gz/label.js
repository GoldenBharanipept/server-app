import { createDecorator } from '../../instantiation/common/instantiation.js';
export const ILabelService = createDecorator('labelService');
